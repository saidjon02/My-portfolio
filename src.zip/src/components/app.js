// let post11 = document.querySelector(".post1");
// let post22 = document.querySelector(".post2");
// let post33 = document.querySelector(".post3");
// let post44 = document.querySelector(".post4");
// let post55 = document.querySelector(".post5");
// const post1 = () => {
//   post11.classList.toggle("opacity");
//   post22.classList.toggle("opacity0");
//   post33.classList.toggle("opacity0");
//   post44.classList.toggle("opacity0");
//   post55.classList.toggle("opacity0");
// };
// const post2 = () => {};
// const post3 = () => {};
// const post4 = () => {};
// const post5 = () => {};
